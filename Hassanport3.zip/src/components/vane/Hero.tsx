import LiquidImage from "./LiquidImage";
import { BRAND, HERO } from "./content";

function Letters({ text, delay }: { text: string; delay: number }) {
    return (
        <span className="hn-line" aria-hidden="true">
            {[...text].map((c, i) => (
                <span key={i} className="hn-ch" style={{ animationDelay: `${delay + i * 52}ms` }}>
                    {c}
                </span>
            ))}
        </span>
    );
}

export default function Hero() {
    return (
        <section id="top" className="hero">
            <div className="hero-top">
                <h2 className="hero-roles">
                    {HERO.roles.map((r, i) => (
                        <span key={r} className="role">
                            <span className="role-i" style={{ animationDelay: `${200 + i * 80}ms` }}>
                                {r}
                            </span>
                        </span>
                    ))}
                </h2>
                <p className="hero-desc">{HERO.description}</p>
            </div>

            <div className="hero-portrait">
                <LiquidImage
                    bare
                    priority
                    src={BRAND.portrait}
                    alt={`${BRAND.full}: portrait`}
                    maxScale={30}
                    position="center bottom"
                    sizes="(min-width: 1024px) 45vw, 100vw"
                    className="hero-fig"
                />
            </div>

            <div className="hero-fade" />

            <h1 className="hero-name" aria-label={BRAND.full}>
                <Letters text={BRAND.first} delay={0} />
                <Letters text={BRAND.last} delay={240} />
            </h1>

            <div className="hero-cue">
                <span className="hero-cue-rule" />
                {HERO.cue}
            </div>
        </section>
    );
}
